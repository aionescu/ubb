class HitEarthError(Exception):
  pass

class HitAsteroidError(Exception):
  pass

class AlreadyHitError(Exception):
  pass