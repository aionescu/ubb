from ui import Ui

def main():
  ui = Ui()

  while True:
    ui.advance_turn()

if __name__ == "__main__":
  main()