#ifndef TEST_HH
#define TEST_HH

void test_Service_tryAddStar();

#endif