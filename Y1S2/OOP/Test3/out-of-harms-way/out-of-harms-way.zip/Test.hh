#ifndef TEST_HH
#define TEST_HH

#include "Services.hh"

void runAllTests();

#endif