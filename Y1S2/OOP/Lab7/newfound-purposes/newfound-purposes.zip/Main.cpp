#include "UI.hh"

int main() {
  UI ui;
  ui.mainLoop();
}