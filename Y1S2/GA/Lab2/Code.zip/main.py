from ui import UI

def main() -> None:
  ui = UI()
  ui.mainLoop()

if __name__ == "__main__":
  main()